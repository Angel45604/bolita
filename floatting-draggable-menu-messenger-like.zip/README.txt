A Pen created at CodePen.io. You can find this one at http://codepen.io/andyNroses/pen/AXwPkb.

 I've always found the messenger menu sexy. Wanted to do one for the web, here it is!
 
Using anime.js & Foundation Icon Fonts 3